'use strict';

/**
 * Default dev server configuration.
 */
const webpack = require('webpack');
const WebpackBaseConfig = require('./Base');
const path = require('path');
const fs = require('fs');

class WebpackDevConfig extends WebpackBaseConfig {

	constructor() {
		super();
		this.config = {
			mode: 'development',
			devtool: 'cheap-module-source-map',
			externals: {'react': 'React', 'react-dom': 'ReactDOM'},
			devServer: {
				contentBase: ['./public/', './src/'],
				publicPath: '/assets/',
				historyApiFallback: true,
				hot: true,
				inline: true,
				port: 3001
			},
			entry: {
				index: [
					'webpack-dev-server/client?http://0.0.0.0:3002/',
					'webpack/hot/only-dev-server',
					'react-hot-loader/patch',
					'babel-polyfill',
					'./index.tsx'
				]
			},
			output: {
				path: path.resolve('./dist/assets'),
				filename: '[name].js',
				publicPath: './assets/'
			},
			plugins: [
				new webpack.DefinePlugin({
					'PRODUCTION': false
				}),
				new webpack.HotModuleReplacementPlugin()
			]
		};

		this.config.module.rules = this.config.module.rules.concat([
			{
				enforce: 'pre',
				test: /\.js?$/,
				include: [].concat(
					this.includedPackages,
					[this.srcPathAbsolute]
				),
				loader: 'babel-loader',
				options: { babelrc: true }
			},
			{
				test: /^.((?!cssmodule).)*\.(sass|scss)$/,
				loaders: [
					{ loader: 'style-loader'
					},
					{
						loader: 'css-loader',
						options: {
							sourceMap: true
						}
					},
					{ loader: 'sass-loader',
						options: {
							sourceMap: true
						}
					}
				]
			}, {
				test: /^.((?!cssmodule).)*\.less$/,
				use: [
					{loader: "style-loader"},
					{
						loader: "css-loader",
						options: {
							sourceMap: true
						}
					}, {
						loader: "less-loader",
						options: {
							sourceMap: true
						}
					}
				]
			},
			{
				test: /\.(png|jpg|gif|mp4|ogg|svg|woff|woff2|ttf|eot|ico)$/,
				loader: 'file-loader',
			}
		]);
	}
}

module.exports = WebpackDevConfig;
