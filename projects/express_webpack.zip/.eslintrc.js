module.exports = {
  "extends": [
    "eslint:recommended",
  ],
  "parser": "babel-eslint"
};

