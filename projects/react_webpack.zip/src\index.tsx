import * as React from "react";
import * as ReactDOM from "react-dom";

ReactDOM.render(
    <div></div>,
    document.getElementById("app-container")
);
