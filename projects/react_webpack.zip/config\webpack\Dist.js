'use strict';

/**
 * Dist configuration. Used to build the
 * final output when running npm run dist.
 */
const webpack = require('webpack');
const WebpackBaseConfig = require('./Base');
const CopyWebpackPlugin = require('copy-webpack-plugin');
// const Visualizer = require('webpack-visualizer-plugin');
const CompressionPlugin = require('compression-webpack-plugin');
// const nodeExternals = require('webpack-node-externals');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin')
//const JavaScriptObfuscator = require('webpack-obfuscator');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

const path = require('path');
const ROOT = path.resolve(__dirname, '../..');
function root(args) {
	args = Array.prototype.slice.call(arguments, 0);
	return path.join.apply(path, [ROOT].concat(args));
}

class WebpackDistConfig extends WebpackBaseConfig {

	constructor() {
		super();
		this.config = {
			/*externals: [nodeExternals()],*/
			cache: false,
			devtool: 'source-map',
			entry: {
				designer: [
					'babel-polyfill',
					'./designer.js'
				],
				runtime: [
					'babel-polyfill',
					'./runtime.js'
				],
				stage: [
					'babel-polyfill',
					'./stage2.js'
				]
			},
			output: {
				path: root('dist'),
				publicPath: '/',
				filename: 'assets/[name].js',
				chunkFilename: 'assets/[name].js'
			},
			optimization: {
				splitChunks: {
					cacheGroups: {
						default: false,
						vendors: false,
						// vendor chunk
						vendor: {
							name: 'vendor',
							// sync + async chunks
							chunks: 'all',
							// import file path containing node_modules
							test: /node_modules/
						}
					} 
				},
				minimizer: [
					new UglifyJsPlugin({
						sourceMap: true
					})
				]
			},
			plugins: [
				new webpack.DefinePlugin({
					'PRODUCTION': true,
					'process.env.NODE_ENV': '"production"'
				}),
				new webpack.optimize.AggressiveMergingPlugin(),
				new webpack.NoEmitOnErrorsPlugin(),
				new webpack.ProvidePlugin({
					$: "jquery",
					jQuery: "jquery",
					"window.jQuery": "jquery"
				}),
				new CompressionPlugin({
					asset: "[path].gz[query]",
					algorithm: "gzip",
					test: /\.js$|\.css$|\.html$/,
					threshold: 10240,
					minRatio: 0.8
				}),
				new CopyWebpackPlugin([
					{from: root('public/index.html'), to: root('dist/') },
					{from: root('public/css'), to: root('dist/css') },
					{from: root('public/img'), to: root('dist/img') },
					{from: root('src/assets/**/*'), to: root('dist/') },
				])/*,
				new BundleAnalyzerPlugin({
					analyzerMode: 'static'
				})*/
			]
		};

		this.config.module.rules = this.config.module.rules.concat([
			{
				enforce: 'pre',
				test: /\.js?$/,
				include: [].concat(
				  this.includedPackages,
				  [this.srcPathAbsolute]
				),
				loader: 'babel-loader',
				options: { babelrc: true }
			},
			{
				test: /^.((?!cssmodule).)*\.(sass|scss)$/,
				loaders: [
					{ loader: 'style-loader' },
					{ loader: 'css-loader' },
					{ loader: 'postcss-loader' },
					{ loader: 'sass-loader' }
				]
			}, {
				test: /^.((?!cssmodule).)*\.less$/,
				loaders: [
					{ loader: 'style-loader' },
					{ loader: 'css-loader' },
					{ loader: 'postcss-loader' },
					{ loader: 'less-loader' }
				]
			},
			{
				test: /\.(png|jpg|gif|mp4|ogg|svg|woff|woff2|ttf|eot|ico)$/,
				loader: 'file-loader',
				options: {
					publicPath: "./",
				}
			}
		])
	}

	/**
	 * Get the environment name
	 * @return {String} The current environment
	 */
	get env() {
		return 'dist';
	}
}

module.exports = WebpackDistConfig;
